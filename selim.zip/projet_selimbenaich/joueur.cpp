#include "joueur.h"

joueur::joueur()
{

}
