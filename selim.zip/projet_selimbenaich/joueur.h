#ifndef JOUEUR_H
#define JOUEUR_H


class joueur
{
public:
    joueur();
};

#endif // JOUEUR_H
